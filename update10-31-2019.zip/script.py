#Checkers game
import pygame

boardImage = pygame.image.load("board.png")
red = pygame.image.load("red.png")
black = pygame.image.load("black.png")
coordinates = []

#edits coordinates
for i in range(8):
    second = []
    for j in range(8):
        third = (j*100, i*100)
        second.append(third)
    coordinates.append(second)

def make_board(black=True):
    black_board = [     [0, 1, 0, 1, 0, 1, 0, 1],
                        [1, 0, 1, 0, 1, 0, 1, 0],
                        [0, 1, 0, 1, 0, 1, 0, 1],
                        [0, 0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0, 0],
                        [2, 0, 2, 0, 2, 0, 2, 0],
                        [0, 2, 0, 2, 0, 2, 0, 2],
                        [2, 0, 2, 0, 2, 0, 2, 0]    ]
    if black==False:
        red_board = [list(map(lambda x: 1 if x==2 else 2 if x==1 else 0,row)) for row in black_board]
        return red_board
    return black_board


def draw_board(board, gameDisplay):
    gameDisplay.blit(boardImage, [0, 0])
    for i in range(8):
        for j in range(8):
            if board[i][j] == 1:
                gameDisplay.blit(red, coordinates[i][j])
            elif board[i][j] == 2:
                gameDisplay.blit(black, coordinates[i][j])

def where_clicked(board, x, y):
    x = x-(x%100)
    y = y-(y%100)
    position = (x,y)
    for row in coordinates:
        for entry in row:
            if entry == position:
                i=coordinates.index(row)
                j=row.index(entry)
    return i,j



if __name__ == "__main__":
    pass

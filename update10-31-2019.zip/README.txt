summary of update:
can move pieces using where_clicked and changing the values of board
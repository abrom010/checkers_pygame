import pygame
import sys

from script import *

#initializing the pygame window and game variables
gameDisplay = pygame.display.set_mode((800, 800))
pygame.display.set_caption('Checkers')

clock = pygame.time.Clock()
board = make_board(black=False)

#main loop
running = True
moving = False
indexes = []
moving_indexes = []
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
        if (event.type == pygame.MOUSEBUTTONDOWN) and (event.button == 1) and moving==False:
            x,y = pygame.mouse.get_pos()
            indexes = where_clicked(board,x,y)
            if board[indexes[0]][indexes[1]]!=0:
                moving = True
                
        if (event.type == pygame.MOUSEBUTTONDOWN) and (event.button == 1) and moving==True:
            x,y = pygame.mouse.get_pos()
            moving_indexes = where_clicked(board,x,y)
            if board[moving_indexes[0]][moving_indexes[1]]==0:
                board[moving_indexes[0]][moving_indexes[1]]=board[indexes[0]][indexes[1]]
                board[indexes[0]][indexes[1]]=0
                moving = False

    draw_board(board, gameDisplay)
    pygame.display.update()
    clock.tick(60)
#end of main loop

pygame.display.quit()
pygame.quit()
sys.exit()

summary of update:
hard coded the coordinates for less calculations
added booleans is_black, player_turn
added player_piece_value which contains the number corresponding to the player's color
make_board now uses boolean to return a board of each color
made screen only update when moving
added translucent pieces when moving
added valid_move() to perform checks on the player's moves
player can now capture one of the opponent's pieces